<!DOCTYPE html>

<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {

      // 1. UI: GET the information from the form
      $emailid = $_POST["email"];
      $password = $_POST["pass"];

      // 2. DB: connect to database

      // ----------------------------------------

    	$dbhost = "localhost";
    	$dbuser = "root";
    	$dbpassword = "";
    	$dbname = "phpexam";

    	$conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

    	// SQL QUERY: 'SELECT * FROM users where username="pritesh" and password="1234"';
      $query = 'SELECT * FROM login where email="'
              . $emailid
              . '" and pass ="'
              . $password
              . '"';

      echo "Query you are sending to db: " . $query  . "<br>";

    	$results = mysqli_query($conn, $query);

      // 3. LOGIC: check if user is in the database
      // If in db, $y = 0
      // Otherwise, $y = 1
      $y = mysqli_num_rows($results);
      echo "Number of rows returned: " . $y . "<br>";

      if ($y == 0) {
          // 4. he is not in the db, so show an error message
          echo "<span style='color:red'> Error - wrong username/password </span><br>";
      }
      else {
          // 5. else, send him to page 2
          header("Location: loggedin.php");
      }

      // ----------------------------------------
  }
?>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" integrity="sha256-zKA1Bf41O96+gJSlkn/Bh2HATW/OhwkApPlYTp3B5O8=" crossorigin="anonymous"/>
    <title></title>
    <style media="screen">
    .one, .two {display:inline-block;}

    </style>
  </head>
  <body>
    Login page
    <div class="" style="margin-left:30%; margin-top:5%; margin-right:40%;">
      <p>Enter your Username & Password below</p> <br>
      <input class="input" type="text" name="email" value="" placeholder="Username / Email"> <br><br>
      <input class="input" type="text" name="pass" value="" placeholder="Password">

      <form class="one" action="loggedin.php" method="post">
        <button type="submit" name="signin">Sign in</button>
      </form>
      <form class="two" action="signup.php" method="get">
        <button type="submit" name="button">Sign up</button>
      </form>
    </div>
  </body>
</html>
