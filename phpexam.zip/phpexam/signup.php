<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" integrity="sha256-zKA1Bf41O96+gJSlkn/Bh2HATW/OhwkApPlYTp3B5O8=" crossorigin="anonymous"/>
    <title></title>
  </head>
  <body> Sign up Page
    <div class="" style="margin-left:30%; margin-top:5%; margin-right:40%;">
      <form class="" action="includes/signup.inc.php" method="POST">

      <input class="input" type="text" name="firstn" value="" placeholder="First name"> <br><br>
      <input class="input" type="text" name="lastn" value="" placeholder="Last name"> <br><br>
      <input class="input" type="text" name="email" value="" placeholder="Email"> <br><br>
      <input class="input" type="password" name="pass" value="" placeholder="Password"> <br><br>
      <button type="submit" name="submit">Sign up</button>
      </form>
    </div>
  </body>
</html>
