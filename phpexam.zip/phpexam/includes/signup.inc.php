
<?php

if (isset($_POST['submit'])) {
  include_once 'database.inc.php';
  $firstn = mysqli_real_escape_string($conn, $_POST['firstn']);
  $lastn = mysqli_real_escape_string($conn, $_POST['lastn']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $pass = mysqli_real_escape_string($conn, $_POST['pass']);

  // error handler
  //
  // if (empty($firstn) || (empty($lastn) || (empty($email) || (empty($pass)) {
  //    header("Location: ../index.php");
  //   // exit();
  // }
  // else {
    $sql = "INSERT INTO login (firstn, lastn, email, pass) VALUES ('$firstn' , '$lastn' , '$email' , '$pass');";
    mysqli_query($conn, $sql);
    header("Location: ../index.php");
    // exit();
  }


else {
  header("Location: ../index.php");
  // exit();
}
