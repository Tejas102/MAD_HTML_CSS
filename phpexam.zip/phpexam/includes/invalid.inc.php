<!DOCTYPE html>

<?php

 ?>


<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <div class="">
      <p>You have successfully created an ID</p>
      <!-- home button & sign in page redirect below -->
    </div>
  </body>
</html>
