$(function() {
02

03
  $('.weather-temperature').openWeather({
04
  city: 'Toronto, ON', // city name, country / province/ state
05
  lat: null // defines the latitude
06
  lng: null // defines the longitude
07
  key: 'YOUR API KEY'
08
  units: "c" // defines the type of units (c or f).
09
  lang: 'en',
10
  descriptionTarget: '.weather-description',
11
  windSpeedTarget: '.weather-wind-speed',
12
  minTemperatureTarget: '.weather-min-temperature',
13
  maxTemperatureTarget: '.weather-max-temperature',
14
  humidityTarget: '.weather-humidity',
15
  sunriseTarget: '.weather-sunrise',
16
  sunsetTarget: '.weather-sunset',
17
  placeTarget: '.weather-place',
18
  iconTarget: '.weather-icon',
19
  customIcons: 'src/img/icons/weather/',
20
  success: function() {
21

22
    //show weather
23
    $('.weather-wrapper').show();
24

25
  },
26
  error: function(message) {}
27
  });
28

29
});
